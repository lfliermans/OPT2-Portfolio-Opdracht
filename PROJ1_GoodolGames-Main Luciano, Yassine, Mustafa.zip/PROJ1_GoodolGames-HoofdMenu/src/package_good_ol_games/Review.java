package src.package_good_ol_games;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class Review {
    private String game;
    private int gameplayRating;
    private int graphicsRating;
    private int storylineRating;
    private String comment;


    public Review(String game, int gameplayRating, int graphicsRating, int storylineRating, String comment) {
        this.game = game;
        this.gameplayRating = gameplayRating;
        this.graphicsRating = graphicsRating;
        this.storylineRating = storylineRating;
        this.comment = comment;
    }


    
    public String getGame() {
        return this.game;
    }


    public int getGameplayRating() {
        return this.gameplayRating;
    }


    public int getGraphicsRating() {
        return this.graphicsRating;
    }


    public int getStorylineRating() {
        return this.storylineRating;
    }


    public String getComment() {
        return this.comment;
    }


 
    public void setGame(String game) {
        this.game = game;
    }


    public void setGameplayRating(int gameplayRating) {
        this.gameplayRating = gameplayRating;
    }


    public void setGraphicsRating(int graphicsRating) {
        this.graphicsRating = graphicsRating;
    }


    public void setStorylineRating(int storylineRating) {
        this.storylineRating = storylineRating;
    }


    public void setComment(String comment) {
        this.comment = comment;
    }


    public static void ReviewVragen(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Kies een spel uit de volgende lijst:");

        Game.addGames(null, null, 0);
        Game.toonGames();

        String game = scanner.nextLine();

        System.out.println("Geef je beoordeling voor de gameplay (1-10):");
        int gameplayRating = scanner.nextInt();

        System.out.println("Geef je beoordeling voor de graphics (1-10):");
        int graphicsRating = scanner.nextInt();

        System.out.println("Geef je beoordeling voor het verhaal (1-10):");
        int storylineRating = scanner.nextInt();

        scanner.nextLine();  
        System.out.println("Geef je commentaar:");
        String comment = scanner.nextLine();

        

        Review review = new Review(game, gameplayRating, graphicsRating, storylineRating, comment);
    

        try {
            FileWriter fileWriter = new FileWriter("reviews.txt", true);
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.println("Game: " + review.getGame());
            printWriter.println("Gameplay Rating: " + review.getGameplayRating());
            printWriter.println("Graphics Rating: " + review.getGraphicsRating());
            printWriter.println("Storyline Rating: " + review.getStorylineRating());
            printWriter.println("Comment: " + review.getComment());
            printWriter.println("-----------------------------------");
            
            System.out.println("Wil je een enquête invullen? (ja/nee)");
            String answer = scanner.nextLine();
    
            if (answer.equalsIgnoreCase("ja")) {
                System.out.println("Wat was je algemene indruk van het spel?");
                String generalImpression = scanner.nextLine();
                printWriter.println("Algemene indruk: " + generalImpression);
    
                System.out.println("Beschrijf kort je ervaring met de gameplay van het spel.");
                String gameplayExperience = scanner.nextLine();
                printWriter.println("Gameplay ervaring: " + gameplayExperience);
    
                System.out.println("Hoe vond je de visuele aspecten van het spel?");
                String visualAspects = scanner.nextLine();
                printWriter.println("Visuele aspecten: " + visualAspects);
    
                System.out.println("Wat vond je van het verhaal of de verhaallijn van het spel?");
                String storyline = scanner.nextLine();
                printWriter.println("Verhaal/verhaallijn: " + storyline);
    
                System.out.println("Zou je dit spel aanbevelen aan anderen? Waarom wel of waarom niet?");
                String recommendation = scanner.nextLine();
                printWriter.println("Aanbeveling: " + recommendation);
                printWriter.println("-----------------------------------");
            }
            printWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred while writing to file: " + e.getMessage());
        }


        scanner.close();
    }
    public static Map<String, double[]> calculateAverageRatingsForAllGames() {
        Map<String, int[]> totalRatingsPerGame = new HashMap<>();
        Map<String, Integer> reviewCountPerGame = new HashMap<>();


        try {
            File file = new File("reviews.txt");
            Scanner scanner = new Scanner(file);


            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();


                if (line.startsWith("Game: ")) {
                    String gameName = line.substring("Game: ".length());
                    int[] ratings = totalRatingsPerGame.getOrDefault(gameName, new int[3]);
                    int reviewCount = reviewCountPerGame.getOrDefault(gameName, 0);


                    for (int i = 0; i < 3; i++) {
                        line = scanner.nextLine();
                        if (line.startsWith("Gameplay Rating: ")) {
                            int rating = Integer.parseInt(line.substring("Gameplay Rating: ".length()));
                            ratings[0] += rating;
                        } else if (line.startsWith("Graphics Rating: ")) {
                            int rating = Integer.parseInt(line.substring("Graphics Rating: ".length()));
                            ratings[1] += rating;
                        } else if (line.startsWith("Storyline Rating: ")) {
                            int rating = Integer.parseInt(line.substring("Storyline Rating: ".length()));
                            ratings[2] += rating;
                        }
                    }


                    totalRatingsPerGame.put(gameName, ratings);
                    reviewCountPerGame.put(gameName, ++reviewCount);
                }
            }


            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }


        Map<String, double[]> averageRatingsPerGame = new HashMap<>();
        for (Map.Entry<String, int[]> entry : totalRatingsPerGame.entrySet()) {
            String gameName = entry.getKey();
            int[] totalRatings = entry.getValue();
            int reviewCount = reviewCountPerGame.get(gameName);


            double[] averageRatings = new double[3];
            for (int i = 0; i < 3; i++) {
                averageRatings[i] = (double) totalRatings[i] / reviewCount;
            }


            averageRatingsPerGame.put(gameName, averageRatings);
        }


        return averageRatingsPerGame;
    }

}

