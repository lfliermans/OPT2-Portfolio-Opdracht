package src.package_good_ol_games;

import java.util.ArrayList;
import java.util.Comparator;

public class SortGenre {

    //Print Game objecten als String
    private static void print(ArrayList<Game> list) {
        for (Game game : list) {
            System.out.println(game.toString());
        }
    }
    //Kopieer van games-lijst
    private static void add(ArrayList<Game> list) {
        list.addAll(Game.getGames());
    }

    //Sorteert op categorie

    private static void sortByCategory(ArrayList<Game> list) {

        list.sort(Comparator.comparing(Game::getCategorie));
    }
    //Maak een nieuwe lijst games en print deze gesorteerd op categorie uit
    public static void sort(){
        ArrayList<Game> list = new ArrayList<>();
        add(list);
        sortByCategory(list);
        print(list);
    }
}