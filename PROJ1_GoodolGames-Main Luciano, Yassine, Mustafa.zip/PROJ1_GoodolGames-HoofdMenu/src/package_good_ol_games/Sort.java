package src.package_good_ol_games;

public abstract class Sort {

}
