package src.package_good_ol_games;

import java.util.Map;

import java.util.*;

public class SortReview {
    public static void sortAndDisplayReviews() {
        Map<String, double[]> averageRatingsPerGame = Review.calculateAverageRatingsForAllGames();

        // Maak een lijst van de entries in de map
        List<Map.Entry<String, double[]>> list = new ArrayList<>(averageRatingsPerGame.entrySet());

        // Sorteer de lijst met een custom comparator
        list.sort(new Comparator<Map.Entry<String, double[]>>() {
            @Override
            public int compare(Map.Entry<String, double[]> o1, Map.Entry<String, double[]> o2) {
                // Bereken het gemiddelde van de beoordelingen voor elke game
                double average1 = (o1.getValue()[0] + o1.getValue()[1] + o1.getValue()[2]) / 3;
                double average2 = (o2.getValue()[0] + o2.getValue()[1] + o2.getValue()[2]) / 3;

                // Vergelijk de gemiddelde beoordelingen van de games
                return Double.compare(average2, average1);
            }
        });

        // Geef de gesorteerde beoordelingen weer
        for (Map.Entry<String, double[]> entry : list) {
            displayRatings(entry.getKey(), entry.getValue());
        }
    }

    public static void displayRatings(String gameName, double[] averageRatings) {
        System.out.println("Average ratings for " + gameName + ":");
        System.out.println("Gameplay: " + averageRatings[0]);
        System.out.println("Graphics: " + averageRatings[1]);
        System.out.println("Storyline: " + averageRatings[2]);
    }
}






