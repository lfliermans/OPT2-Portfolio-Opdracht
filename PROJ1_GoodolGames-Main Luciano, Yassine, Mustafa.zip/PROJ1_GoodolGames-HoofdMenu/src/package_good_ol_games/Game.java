package src.package_good_ol_games;

import java.util.ArrayList;

public class Game {
String naam; 
String categorie;
int prijs;
static  ArrayList<Game> games = new ArrayList<Game>();
boolean sale;





public Game(String naam, String categorie, int prijs, boolean sale){
    this.naam = naam;
    this.categorie = categorie;
    this.prijs = prijs;
    this.sale = sale;
    
}

public static void addGames(String naam, String categorie, int prijs){
    games.add(new Game("Grand Theft Auto V", "RPG", 50, true));
    games.add(new Game("FIFA 23", "Sport", 60, false));
    games.add(new Game("Call of Duty", "Shooter", 70, false));
    games.add(new Game("NBA 2K23", "Sport", 60, false));
    games.add(new Game("Skyrim", "RPG", 40, true));
    games.add(new Game("Battlefield", "Shooter", 70, false));
}


//Getters
    public String getCategorie() {
        return categorie;
    }
    public String getNaam(){
        return naam;
    }

    public int getPrijs() {
        return prijs;
    }

    public boolean getSale(){
        return sale;
    }
    public String getSaleString(){
        if (getSale()){
            return "Ja";
        } else {
            return "Nee";
        }
    }

    public static ArrayList<Game> getGames() {
        return games;

    }

     //toString
    public String toString(){
        return "Naam: " + getNaam() + " Categorie: " + getCategorie() + " Prijs: " + getPrijs() + " Uitverkoop: " + getSaleString();

    }

    

public static void toonGames(){

    for(Game game : games){

        System.out.println("Naam: " + game.naam + " Categorie: " + game.categorie + " Prijs: " + game.prijs + " Uitverkoop: " + game.getSaleString());
    }
}


}
