package src.package_good_ol_games;
import java.util.Scanner;

public class HoofdMenu {

    Scanner sc = new Scanner(System.in);

    public void BeginMenu() {
        System.out.println("  _     _ ");
        System.out.println(" | |   (_)");
        System.out.println(" | |__  _ ");
        System.out.println(" | '_ \\| |");
        System.out.println(" | | | | |");
        System.out.println(" |_| |_|_|");
        System.out.println("=======================================================");
        System.out.println("||                                                   ||");
        System.out.println("||   Welkom bij 8-bit reviews van Good Ol' Games!    ||");
        System.out.println("||                                                   ||");
        System.out.println("||   1. Bekijk een lijst met games                   ||");
        System.out.println("||   2. Plaats een review                            ||");
        System.out.println("||   3. Ranglijsten                                  ||");
        System.out.println("||                                                   ||");
        System.out.println("||                                                   ||");
        System.out.println("=======================================================");

        System.out.println("Selecteer een optie door het bijbehorende nummer in te typen:");

        int keuze = 0;
        keuze = sc.nextInt();
        sc.nextLine();
        switch (keuze) {
            case 1:
                Game.addGames(null, null, keuze);
                Game.toonGames();
                System.out.println("");
                System.out.println("1: Terug naar hoofdmenu");
                System.out.println("2: Sorteren op categorie");
                System.out.println("3: Sorteren op uitverkoop");
                System.out.println("4: Afsluiten");
                int keuze2 = 0;
                keuze2 = sc.nextInt();
                sc.nextLine();
                switch (keuze2) {
                    case 1:
                        BeginMenu();
                        break;
                            case 2:
                        SortGenre.sort();
                        System.out.println("1: Terug naar hoofdmenu");
                        System.out.println("2: Afsluiten");
                        int keuze3 = 0;
                        keuze3 = sc.nextInt();
                        sc.nextLine();
                        switch (keuze3) {
                            case 1:
                                BeginMenu();
                                break;
                            case 2:
                                System.exit(0);
                            default:
                                System.out.println("Voer een keuze in");
                        }

                    case 3:
                        SortSale.sort();
                        System.out.println("1: Terug naar hoofdmenu");
                        System.out.println("2: Afsluiten");
                        int keuze4 = 0;
                        keuze4 = sc.nextInt();
                        sc.nextLine();
                        switch (keuze4) {
                            case 1:
                                BeginMenu();
                                break;
                            case 2:
                                System.exit(0);
                        }


                    case 4:
                        System.exit(0);

                    default:
                        System.out.println("Voer een keuze in");
                }
            case 2:
                Game.addGames(null, null, keuze);
                Review.ReviewVragen(null);

            case 3:
                SortReview.sortAndDisplayReviews();
                System.out.println("1: Terug naar hoofdmenu");
                System.out.println("2: Afsluiten");
                int keuze5 = 0;
                keuze5 = sc.nextInt();
                sc.nextLine();
                switch (keuze5) {
                    case 1:
                        BeginMenu();
                        break;
                    case 2:
                        System.exit(0);


                    case 4:
                    case 5:
                        System.exit(0);
                    default:
                        System.out.println("Ongeldige Keuze. Probeer opnieuw. ");
                        BeginMenu();
                }
        }
    }
}






/*try {
    int keuze = sc.nextInt();

    if (keuze<1 || keuze>4){
        System.out.println("Deze optie staat niet in de lijst. Probeer het opnieuw!");
        BeginMenu();
    }
    else if (keuze == 1){
        System.err.println("");
        Game.addGames( null, null, 0);
        Game.toonGames();
        System.out.println("");
        System.out.println("Wilt uw terug naar het hoofdmenu?  J/N");
        String antwoord = sc.next();

        if (antwoord.equals("J") || antwoord.equals("j")){
            
            BeginMenu();
            System.out.flush();
        }
        else if (antwoord.equals("N") || antwoord.equals("n")){
            System.out.println("Tot ziens!");
            System.exit(0);
            
        }
        else {
            System.out.println("Voer alleen J of N in!");
        }
            
    
    }
    else if (keuze == 2){
        Review.ReviewVragen(null);
    }
    else if (keuze == 3){
       // Korting.toonKortingen();
    }
    else if (keuze == 4){
        //Sort.Ranglijst();
    }
    else if (keuze == 5){
        SortGenre.sort();
                        System.out.println("1: Terug naar hoofdmenu");
                        System.out.println("2: Afsluiten");
    }
    
} catch (InputMismatchException e) {
    System.out.println("Voer alleen een cijfer in!");
    sc.next(); 
    BeginMenu();
 }*/

 