package src.package_good_ol_games;

import java.util.ArrayList;
import java.util.Comparator;

public class SortSale extends Sort {
    //Print Game objecten als String
    private static void print(ArrayList<Game> list) {
        for (Game game : list) {
            System.out.println(game.toString());
        }
    }
    //Kopieer van games-lijst
    private static void add(ArrayList<Game> list) {
        list.addAll(Game.getGames());
    }

    //Sorteert op cuitverkoop

    private static void sortBySale(ArrayList<Game> list) {

        list.sort(Comparator.comparing(Game::getSale).reversed());
    }
    //Maak een nieuwe lijst games en print deze gesorteerd op uitverkoop uit
    public static void sort(){
        ArrayList<Game> list = new ArrayList<>();
        add(list);
        sortBySale(list);
        print(list);
    }

}
