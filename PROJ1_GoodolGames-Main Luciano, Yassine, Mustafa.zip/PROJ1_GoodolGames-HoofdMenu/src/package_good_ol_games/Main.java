package src.package_good_ol_games;


public class Main {

    public static void main(String[] args) {
        HoofdMenu scherm = new HoofdMenu();
        
        scherm.BeginMenu();


      
    }
}
   